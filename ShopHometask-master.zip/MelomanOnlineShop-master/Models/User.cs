﻿using Models.Abstract;
using System;

namespace Models
{
    public class User : Entity
    {
        public string PhoneNumber { get; set; }       
    }
}
