﻿using Models.Abstract;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models
{
    public class Genre : Entity
    {
        public string Name { get; set; }
    }
}
