﻿using Models.Abstract;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models
{
    public class Author : Entity
    {       
        public string Name { get; set; }
    }
}
